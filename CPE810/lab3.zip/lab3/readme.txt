Type "make" to build the code. Binary takes in the following arguments:
-dimX=M where M is width of the input array
-dimY=N where N is the height of the input array
-dimK=P where P is the width and height of the mask array
Examples:
./conv -dimX=3098 -dimY=4031 -dimK=9
