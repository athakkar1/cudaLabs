Type "make" to build the code. Binary takes in the following arguments:
-binNum=M where M is the number of bins
-inputSize=N where N is the size of the input array
Error checking makes sure number of bins is power of two from 4 to 256.

Examples:
./hist -binNum=256 -inputSize=53450079
