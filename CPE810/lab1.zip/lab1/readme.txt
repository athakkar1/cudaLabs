Type "make" to build the code. Binary takes in the following arguments:
-hA=M where M is the height of matrix A
-wA=N where N is the width of matrix A and height of matrix B
-wB=P where P is the width of matrix B

Examples:
./matrixMulMine -hA=127 -wA=131 -wB=129
